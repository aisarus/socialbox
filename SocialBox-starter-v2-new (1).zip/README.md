# SocialBox (starter v2)

Generative social sandbox: Minecraft-like building + Godus-like look.
tFM/TRI rule-based sim first; optional local LLM via Ollama.

## Structure
/game/  engine project (Godot/Unity)
/server/ FastAPI + optional Ollama
/core/   rules (JSON) + storylets + schemas
/docs/   notes

MIT © 2025
