Godus-look, tFM/TRI core, LLM optional.
